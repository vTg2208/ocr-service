# Privacy and retention policy baseline

AranyaSetu processes FRA case records and supporting evidence; it does not determine or transfer legal ownership, establish an FRA right, or approve a scheme benefit.

## Data classification and access

- Uploaded FRA and supporting cadastral documents, raw OCR, claimant identifiers, and case evidence are restricted personal data.
- FRA rights-holder identities, external references, claimant categories, Gram Sabha links, declared DSS facts, and evidence provenance are restricted case data.
- Normal users may read only their documents, claims, and generic notifications.
- Normal FRA users do not receive rights-holder external references; reviewer and administrator access remains authenticated and purpose-limited.
- Parcel endpoints contain registry geometry and provenance only; they never contain claimant or document data.
- Detailed conflict evidence is restricted to the `admin` role and every resolution is audited.
- S3 storage must use private buckets, blocked public access, server-side encryption, and a narrowly scoped API role.
- Satellite source URIs are private metadata. API responses expose the observation and supporting-evidence label without returning the source URI.
- STAC asset references, signed query strings, derived-artifact storage keys, and model endpoints are restricted processing metadata. Historical reports expose provider, collection, acquisition, licence, versions, metrics, and quality flags only.
- DSS audit and recommendation rows may retain declared facts and rule identifiers, but never raw document content.
- FRA archive raw text, reviewed fields, extraction evidence, and printable archive reports are restricted reviewer data. Archive reports require reviewer or administrator access.
- Atlas responses minimize rights-holder identifiers for normal users. Private source/artifact URIs are excluded from asset, model, and report responses.
- DSS fact snapshots contain derived values and source entity/version identifiers, never rights-holder names, raw OCR, private URIs, or contact fields. Operational planner dashboards aggregate counts; verifier queues expose case/archive references and locations only.
- Synthetic status is a mandatory provenance field, not a substitute for access control.

## Retention

- Open claims, open conflicts, audit events, and the cadastral source/version history are retained while legally or operationally required.
- FRA decisions, geometry versions, title versions, evidence verification history, satellite observations, and DSS evaluations remain versioned or append-only while the case and applicable retention duty require them.
- Rejected uploads that never create a valid document row are removed immediately.
- Closed-case document retention must be configured with the responsible authority before production; the recommended baseline is seven years unless local law requires otherwise.
- Audit events are append-only. Corrections add events and do not overwrite historical evidence.
- A legal hold suspends deletion for all related documents, OCR results, claims, conflicts, and audits.
- Processing-job payloads, extraction runs, inference runs, asset revisions, DSS referrals, and generated-report audit events follow the related case retention duty. Failed jobs must be quarantined or expired by an approved retention job, never silently discarded.

## Subject and administrator operations

- Access/export and erasure requests require identity verification and an authorization/legal-retention check.
- Deletion must remove the storage object and personal database records in a controlled job while preserving any legally required pseudonymized audit evidence.
- Never place raw OCR, names, tokens, document contents, or signed storage URLs in application logs.

## Production release gate

Before launch, document the controller/processor, lawful basis, geographic storage region, retention duration, incident contact, encryption/key ownership, backup retention, restore test date, and approved cadastral-data license.

For FRA operational use, also document the authoritative Tamil Nadu reference-data license and version, the approved scheme-rule authority, model training/evaluation data governance, bias and error review, model activation approver, human-review procedure, report access purpose, and the process for correcting an observation without overwriting its history.
